import { useState, useEffect, useRef } from "react";

const NAV_ITEMS = ["الرئيسية", "الكولكشن", "الغرف", "من نحن", "تواصل معنا"];

const CATEGORIES = [
  { name: "غرف المعيشة", count: "٤٨ قطعة", emoji: "🛋️" },
  { name: "غرف النوم", count: "٣٢ قطعة", emoji: "🛏️" },
  { name: "غرف الطعام", count: "٢٤ قطعة", emoji: "🪑" },
  { name: "المكتب الفاخر", count: "١٦ قطعة", emoji: "🖊️" },
  { name: "الديكور", count: "٦٠ قطعة", emoji: "🪴" },
];

const PRODUCTS = [
  { name: "طقم صالة ملكي", price: "٤٥٠,٠٠٠", material: "خشب جوز أمريكي + قماش إيطالي", tag: "جديد", type: "sofa" },
  { name: "غرفة نوم فاخرة", price: "٣٨٠,٠٠٠", material: "خشب زان + مرايا مُطوَّقة", tag: "مميز", type: "bed" },
  { name: "طاولة طعام ملكية", price: "١٨٠,٠٠٠", material: "رخام كاراره + قاعدة بلوط", tag: "", type: "table" },
  { name: "ركنة كابوتشينو", price: "٢٢٠,٠٠٠", material: "جلد طبيعي فاخر مستورد", tag: "الأكثر طلباً", type: "armchair" },
  { name: "سرير كينج كلاسيك", price: "٢٩٠,٠٠٠", material: "خشب ماهوجني مصري أصيل", tag: "", type: "kingbed" },
  { name: "خزانة ملابس إيطالية", price: "٣١٠,٠٠٠", material: "خشب صاج + جلد ومرايا", tag: "جديد", type: "wardrobe" },
];

const STATS = [
  { value: "١٥+", label: "سنة خبرة" },
  { value: "٥,٠٠٠+", label: "عميل راضٍ" },
  { value: "٢٠٠+", label: "تصميم فريد" },
  { value: "٣", label: "فروع في العراق" },
];

const PROMISES = [
  { icon: "🏆", title: "جودة مضمونة", desc: "كل منتج مفحوص قبل التسليم" },
  { icon: "🚚", title: "توصيل وتركيب", desc: "مجاني داخل بغداد خلال ٥ أيام" },
  { icon: "🎨", title: "تصميم مخصص", desc: "نصنع ما يناسب ذوقك ومساحتك" },
  { icon: "🛡️", title: "ضمان ٥ سنوات", desc: "على جميع قطع الأثاث" },
];

// SVG furniture silhouettes — geometric minimal, amber palette
function FurnitureSilhouette({ type }: { type: string }) {
  const g = "rgba(217,119,6,0.18)";
  const s = "rgba(217,119,6,0.32)";
  const la = "rgba(245,158,11,0.12)";
  const ls = "rgba(245,158,11,0.25)";
  const leg = "rgba(180,83,9,0.22)";
  const legs = "rgba(180,83,9,0.32)";

  if (type === "sofa") return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="12" y="72" width="136" height="38" rx="9" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="22" y="56" width="116" height="22" rx="7" fill={la} stroke={ls} strokeWidth="1.5"/>
      <rect x="8" y="56" width="20" height="54" rx="7" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="132" y="56" width="20" height="54" rx="7" fill={g} stroke={s} strokeWidth="1.5"/>
      <line x1="80" y1="56" x2="80" y2="78" stroke={ls} strokeWidth="1.2"/>
      <rect x="26" y="108" width="9" height="10" rx="3" fill={leg} stroke={legs} strokeWidth="1"/>
      <rect x="125" y="108" width="9" height="10" rx="3" fill={leg} stroke={legs} strokeWidth="1"/>
    </svg>
  );

  if (type === "bed") return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="14" y="62" width="132" height="46" rx="6" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="14" y="36" width="22" height="72" rx="5" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="32" y="52" width="44" height="16" rx="4" fill={la} stroke={ls} strokeWidth="1.2"/>
      <rect x="84" y="52" width="44" height="16" rx="4" fill={la} stroke={ls} strokeWidth="1.2"/>
      <rect x="36" y="88" width="36" height="18" rx="4" fill={la} stroke={ls} strokeWidth="1"/>
      <rect x="88" y="88" width="36" height="18" rx="4" fill={la} stroke={ls} strokeWidth="1"/>
    </svg>
  );

  if (type === "table") return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="8" y="52" width="144" height="14" rx="6" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="28" y="66" width="10" height="44" rx="4" fill={leg} stroke={legs} strokeWidth="1.2"/>
      <rect x="122" y="66" width="10" height="44" rx="4" fill={leg} stroke={legs} strokeWidth="1.2"/>
      <rect x="48" y="38" width="64" height="16" rx="5" fill={la} stroke={ls} strokeWidth="1.2"/>
      <ellipse cx="80" cy="38" rx="14" ry="4" fill={la} stroke={ls} strokeWidth="1"/>
    </svg>
  );

  if (type === "armchair") return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="32" y="68" width="96" height="38" rx="10" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="44" y="52" width="72" height="22" rx="8" fill={la} stroke={ls} strokeWidth="1.5"/>
      <rect x="22" y="52" width="26" height="54" rx="8" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="112" y="52" width="26" height="54" rx="8" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="40" y="104" width="9" height="12" rx="3" fill={leg} stroke={legs} strokeWidth="1"/>
      <rect x="111" y="104" width="9" height="12" rx="3" fill={leg} stroke={legs} strokeWidth="1"/>
    </svg>
  );

  if (type === "kingbed") return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="10" y="60" width="140" height="48" rx="6" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="10" y="36" width="24" height="72" rx="5" fill={g} stroke={s} strokeWidth="1.5"/>
      <rect x="30" y="46" width="38" height="18" rx="4" fill={la} stroke={ls} strokeWidth="1.3"/>
      <rect x="76" y="46" width="38" height="18" rx="4" fill={la} stroke={ls} strokeWidth="1.3"/>
      <rect x="120" y="46" width="30" height="18" rx="4" fill={la} stroke={ls} strokeWidth="1"/>
      <line x1="34" y1="86" x2="34" y2="108" stroke={legs} strokeWidth="1.5"/>
      <line x1="128" y1="86" x2="128" y2="108" stroke={legs} strokeWidth="1.5"/>
    </svg>
  );

  // wardrobe
  return (
    <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
      <rect x="18" y="18" width="124" height="96" rx="6" fill={g} stroke={s} strokeWidth="1.5"/>
      <line x1="80" y1="18" x2="80" y2="114" stroke={s} strokeWidth="1.5"/>
      <rect x="24" y="24" width="50" height="32" rx="4" fill={la} stroke={ls} strokeWidth="1"/>
      <rect x="86" y="24" width="50" height="32" rx="4" fill={la} stroke={ls} strokeWidth="1"/>
      <circle cx="66" cy="72" r="4" fill="rgba(245,158,11,0.45)" stroke="rgba(217,119,6,0.6)" strokeWidth="1.2"/>
      <circle cx="94" cy="72" r="4" fill="rgba(245,158,11,0.45)" stroke="rgba(217,119,6,0.6)" strokeWidth="1.2"/>
      <line x1="24" y1="100" x2="74" y2="100" stroke={ls} strokeWidth="1"/>
      <line x1="86" y1="100" x2="136" y2="100" stroke={ls} strokeWidth="1"/>
    </svg>
  );
}

// Ambient orbs layer
function AmbientOrbs() {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: "-12%", right: "-8%", width: "55vw", height: "55vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(245,158,11,0.11) 0%, transparent 68%)" }} />
      <div style={{ position: "absolute", top: "18%", left: "-12%", width: "48vw", height: "48vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(251,191,36,0.07) 0%, transparent 68%)" }} />
      <div style={{ position: "absolute", bottom: "15%", right: "22%", width: "38vw", height: "38vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(217,119,6,0.08) 0%, transparent 68%)" }} />
      <div style={{ position: "absolute", bottom: "-6%", left: "12%", width: "42vw", height: "42vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(245,158,11,0.065) 0%, transparent 68%)" }} />
      <div style={{ position: "absolute", top: "50%", left: "45%", width: "30vw", height: "30vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(245,158,11,0.05) 0%, transparent 68%)", transform: "translate(-50%,-50%)" }} />
    </div>
  );
}

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [activeNav, setActiveNav] = useState("الرئيسية");
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div dir="rtl" style={{ fontFamily: "'Cairo', sans-serif", backgroundColor: "#faf9f7", minHeight: "100vh", overflowX: "hidden", position: "relative" }}>
      <AmbientOrbs />

      {/* ── NAVBAR ── */}
      <nav
        style={{
          position: "fixed",
          top: "14px",
          left: "50%",
          transform: "translateX(-50%)",
          width: "calc(100% - 40px)",
          maxWidth: "1180px",
          zIndex: 100,
          background: scrolled ? "rgba(255,255,255,0.72)" : "rgba(255,255,255,0.48)",
          backdropFilter: "blur(28px) saturate(180%)",
          WebkitBackdropFilter: "blur(28px) saturate(180%)",
          border: scrolled ? "1px solid rgba(245,158,11,0.20)" : "1px solid rgba(255,255,255,0.72)",
          borderRadius: "22px",
          boxShadow: scrolled
            ? "0 16px 48px rgba(0,0,0,0.10), 0 0 0 1px rgba(255,255,255,0.4), inset 0 1px 0 rgba(255,255,255,0.92)"
            : "0 6px 28px rgba(0,0,0,0.055), inset 0 1px 0 rgba(255,255,255,0.92)",
          transition: "all 0.38s ease",
          padding: "10px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "16px",
        }}
      >
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
          <div style={{
            width: "38px", height: "38px", borderRadius: "11px",
            background: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 4px 14px rgba(217,119,6,0.38), inset 0 1px 0 rgba(255,255,255,0.25)",
          }}>
            <span style={{ color: "white", fontSize: "17px", fontWeight: "900", lineHeight: 1 }}>ر</span>
          </div>
          <div>
            <div style={{ fontSize: "16px", fontWeight: "900", color: "#1c1917", lineHeight: 1.1, letterSpacing: "-0.02em" }}>رشاد هوم</div>
            <div style={{ fontSize: "10px", color: "#a8a29e", fontWeight: "500", letterSpacing: "0.04em" }}>RASHAD HOME</div>
          </div>
        </div>

        {/* Links */}
        <div style={{ display: "flex", gap: "3px", alignItems: "center" }}>
          {NAV_ITEMS.map((item) => {
            const active = activeNav === item;
            return (
              <button
                key={item}
                onClick={() => setActiveNav(item)}
                style={{
                  padding: "7px 15px",
                  borderRadius: "11px",
                  fontSize: "13.5px",
                  fontWeight: active ? "700" : "500",
                  color: active ? "#92400e" : "#78716c",
                  background: active ? "linear-gradient(135deg, rgba(245,158,11,0.13), rgba(217,119,6,0.08))" : "transparent",
                  border: active ? "1px solid rgba(245,158,11,0.28)" : "1px solid transparent",
                  cursor: "pointer",
                  transition: "all 0.18s ease",
                  fontFamily: "'Cairo', sans-serif",
                  whiteSpace: "nowrap",
                }}
              >
                {item}
              </button>
            );
          })}
        </div>

        {/* CTA */}
        <button
          style={{
            padding: "9px 22px",
            borderRadius: "13px",
            fontSize: "13px",
            fontWeight: "700",
            color: "white",
            background: "linear-gradient(135deg, #f59e0b, #d97706)",
            border: "none",
            cursor: "pointer",
            boxShadow: "0 4px 16px rgba(217,119,6,0.30), inset 0 1px 0 rgba(255,255,255,0.20)",
            fontFamily: "'Cairo', sans-serif",
            whiteSpace: "nowrap",
            transition: "box-shadow 0.2s ease",
            flexShrink: 0,
          }}
        >
          تواصل معنا
        </button>
      </nav>

      {/* ── HERO ── */}
      <section
        ref={heroRef}
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          padding: "120px 28px 80px",
          position: "relative",
          zIndex: 1,
        }}
      >
        <div style={{ maxWidth: "1180px", width: "100%", margin: "0 auto" }}>
          <div style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "56px",
            alignItems: "center",
          }}>
            {/* Left: text */}
            <div style={{ display: "flex", flexDirection: "column", gap: "28px" }}>
              {/* Badge */}
              <div style={{
                display: "inline-flex", alignItems: "center", gap: "8px",
                padding: "6px 16px", borderRadius: "100px",
                background: "rgba(255,255,255,0.55)", backdropFilter: "blur(14px)",
                WebkitBackdropFilter: "blur(14px)",
                border: "1px solid rgba(245,158,11,0.32)",
                width: "fit-content",
                boxShadow: "0 2px 10px rgba(217,119,6,0.08)",
              }}>
                <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "linear-gradient(135deg,#f59e0b,#d97706)", display: "inline-block", boxShadow: "0 0 6px rgba(245,158,11,0.6)" }} />
                <span style={{ fontSize: "13px", fontWeight: "600", color: "#92400e" }}>كولكشن ٢٠٢٥ متاح الآن ✦</span>
              </div>

              <h1 style={{
                margin: 0,
                fontSize: "clamp(38px, 5vw, 66px)",
                fontWeight: "900",
                lineHeight: "1.09",
                color: "#1c1917",
                letterSpacing: "-0.03em",
              }}>
                أثاث يعكس
                <br />
                <span style={{
                  background: "linear-gradient(135deg, #f59e0b 0%, #d97706 50%, #b45309 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}>
                  ذوقك الفاخر
                </span>
              </h1>

              <p style={{
                margin: 0, fontSize: "16px", lineHeight: "1.85",
                color: "#78716c", fontWeight: "400", maxWidth: "400px",
              }}>
                في رشاد هوم نصنع لك بيتاً يليق بك — من أجود الخامات الخشبية المستوردة وأرقى التصاميم الكلاسيكية والمعاصرة، بحرفية عراقية أصيلة منذ ٢٠٠٩.
              </p>

              <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", alignItems: "center" }}>
                <button style={{
                  padding: "14px 34px", borderRadius: "15px",
                  fontSize: "15px", fontWeight: "800", color: "white",
                  background: "linear-gradient(135deg, #f59e0b, #d97706)",
                  border: "none", cursor: "pointer",
                  boxShadow: "0 8px 28px rgba(217,119,6,0.36), inset 0 1px 0 rgba(255,255,255,0.22)",
                  fontFamily: "'Cairo', sans-serif", transition: "transform 0.2s ease, box-shadow 0.2s ease",
                }}>
                  استعرض الكولكشن ←
                </button>
                <button style={{
                  padding: "14px 28px", borderRadius: "15px",
                  fontSize: "15px", fontWeight: "600", color: "#92400e",
                  background: "rgba(255,255,255,0.55)",
                  backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)",
                  border: "1px solid rgba(245,158,11,0.30)", cursor: "pointer",
                  fontFamily: "'Cairo', sans-serif",
                  boxShadow: "0 4px 14px rgba(0,0,0,0.055)",
                }}>
                  تعرف علينا
                </button>
              </div>

              {/* Mini trust badges */}
              <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                {["✦ ضمان ٥ سنوات", "✦ توصيل مجاني", "✦ تصنيع محلي"].map((t, i) => (
                  <span key={i} style={{ fontSize: "12px", fontWeight: "600", color: "#b45309" }}>{t}</span>
                ))}
              </div>
            </div>

            {/* Right: hero glass card + floating chips */}
            <div style={{ position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}>
              {/* Main featured card */}
              <div
                className="glass-card"
                style={{
                  width: "100%", maxWidth: "420px",
                  borderRadius: "32px", padding: "28px",
                  display: "flex", flexDirection: "column", gap: "20px",
                  position: "relative", overflow: "hidden",
                }}
              >
                {/* Internal amber glow */}
                <div style={{
                  position: "absolute", top: "-40px", right: "-40px",
                  width: "200px", height: "200px", borderRadius: "50%",
                  background: "radial-gradient(circle, rgba(245,158,11,0.14) 0%, transparent 70%)",
                  pointerEvents: "none",
                }} />
                <div style={{
                  position: "absolute", bottom: "-30px", left: "-30px",
                  width: "150px", height: "150px", borderRadius: "50%",
                  background: "radial-gradient(circle, rgba(217,119,6,0.10) 0%, transparent 70%)",
                  pointerEvents: "none",
                }} />

                {/* Tag row */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{
                    padding: "5px 14px", borderRadius: "100px",
                    background: "linear-gradient(135deg, rgba(245,158,11,0.15), rgba(217,119,6,0.10))",
                    border: "1px solid rgba(245,158,11,0.35)",
                    fontSize: "12px", fontWeight: "700", color: "#92400e",
                  }}>✦ القطعة المميزة</span>
                  <span style={{ fontSize: "11px", color: "#a8a29e", fontWeight: "500" }}>رشاد هوم ✦</span>
                </div>

                {/* Product illustration area */}
                <div style={{
                  height: "200px", borderRadius: "22px",
                  background: "linear-gradient(155deg, rgba(245,158,11,0.06) 0%, rgba(255,255,255,0.32) 50%, rgba(217,119,6,0.04) 100%)",
                  border: "1px solid rgba(255,255,255,0.64)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  position: "relative", overflow: "hidden",
                }}>
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px", background: "linear-gradient(90deg, transparent, rgba(245,158,11,0.30), transparent)" }} />
                  <FurnitureSilhouette type="sofa" />
                </div>

                {/* Info */}
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <p style={{ margin: 0, fontSize: "18px", fontWeight: "800", color: "#1c1917", letterSpacing: "-0.02em" }}>طقم صالة ملكي</p>
                      <p style={{ margin: 0, fontSize: "12.5px", color: "#a8a29e", fontWeight: "400", marginTop: "2px" }}>خشب جوز أمريكي + قماش إيطالي</p>
                    </div>
                    <div style={{ textAlign: "left" }}>
                      <p style={{ margin: 0, fontSize: "22px", fontWeight: "900", color: "#d97706", lineHeight: 1, letterSpacing: "-0.02em" }}>٤٥٠,٠٠٠</p>
                      <p style={{ margin: 0, fontSize: "10.5px", color: "#a8a29e", fontWeight: "500" }}>دينار عراقي</p>
                    </div>
                  </div>
                  <button style={{
                    width: "100%", padding: "12px", borderRadius: "14px",
                    background: "linear-gradient(135deg, #f59e0b, #d97706)",
                    border: "none", color: "white", fontSize: "14px", fontWeight: "800",
                    cursor: "pointer", fontFamily: "'Cairo', sans-serif",
                    boxShadow: "0 6px 20px rgba(217,119,6,0.30)",
                    letterSpacing: "0.01em",
                  }}>
                    اطلب الآن ←
                  </button>
                </div>
              </div>

              {/* Floating badge: delivery */}
              <div
                className="glass-strong"
                style={{
                  position: "absolute", top: "16px", left: "-52px",
                  padding: "13px 16px", borderRadius: "18px",
                  display: "flex", alignItems: "center", gap: "10px",
                  animation: "float 4s ease-in-out infinite",
                }}
              >
                <div style={{
                  width: "36px", height: "36px", borderRadius: "10px",
                  background: "linear-gradient(135deg, rgba(245,158,11,0.16), rgba(217,119,6,0.10))",
                  border: "1px solid rgba(245,158,11,0.25)",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px", flexShrink: 0,
                }}>🏠</div>
                <div>
                  <p style={{ margin: 0, fontSize: "12px", fontWeight: "700", color: "#1c1917" }}>توصيل مجاني</p>
                  <p style={{ margin: 0, fontSize: "11px", color: "#78716c" }}>لجميع أنحاء العراق</p>
                </div>
              </div>

              {/* Floating badge: rating */}
              <div
                className="glass-strong"
                style={{
                  position: "absolute", bottom: "52px", left: "-44px",
                  padding: "12px 16px", borderRadius: "16px",
                  animation: "float 5s ease-in-out infinite 1.5s",
                }}
              >
                <p style={{ margin: "0 0 4px 0", fontSize: "10.5px", color: "#a8a29e", fontWeight: "500" }}>تقييم العملاء</p>
                <div style={{ display: "flex", gap: "2px", marginBottom: "3px" }}>
                  {[0,1,2,3,4].map(i => <span key={i} style={{ color: "#f59e0b", fontSize: "13px" }}>★</span>)}
                </div>
                <p style={{ margin: 0, fontSize: "12px", fontWeight: "700", color: "#1c1917" }}>٤.٩ من ٥,٠٠٠+ تقييم</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div
            className="glass"
            style={{
              borderRadius: "28px", padding: "36px 56px",
              display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "28px",
            }}
          >
            {STATS.map((stat, i) => (
              <div key={i} style={{
                display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center",
                borderRight: i < STATS.length - 1 ? "1px solid rgba(245,158,11,0.14)" : "none",
                paddingRight: i < STATS.length - 1 ? "28px" : 0,
              }}>
                <span style={{ fontSize: "44px", fontWeight: "900", color: "#d97706", lineHeight: 1, letterSpacing: "-0.03em" }}>{stat.value}</span>
                <span style={{ fontSize: "13px", color: "#78716c", marginTop: "7px", fontWeight: "500" }}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div style={{ marginBottom: "32px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <p style={{ margin: "0 0 8px 0", fontSize: "12.5px", fontWeight: "700", color: "#d97706", letterSpacing: "0.06em", textTransform: "uppercase" }}>▪ تصفح التصنيفات</p>
              <h2 style={{ margin: 0, fontSize: "clamp(26px, 3vw, 38px)", fontWeight: "900", color: "#1c1917", letterSpacing: "-0.025em", lineHeight: 1.12 }}>أثِّث كل غرفة<br/>بأناقة لا مثيل لها</h2>
            </div>
            <button style={{
              padding: "10px 22px", borderRadius: "12px",
              background: "rgba(255,255,255,0.52)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
              border: "1px solid rgba(245,158,11,0.28)", color: "#92400e",
              fontSize: "13px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif",
              transition: "all 0.2s ease",
            }}>عرض الكل ←</button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: "14px" }}>
            {CATEGORIES.map((cat, i) => {
              const active = i === 0;
              return (
                <div
                  key={i}
                  style={{
                    borderRadius: "24px", padding: "28px 18px",
                    background: active
                      ? "linear-gradient(145deg, rgba(245,158,11,0.16), rgba(217,119,6,0.09))"
                      : "rgba(255,255,255,0.42)",
                    backdropFilter: "blur(22px) saturate(160%)", WebkitBackdropFilter: "blur(22px) saturate(160%)",
                    border: active ? "1px solid rgba(245,158,11,0.42)" : "1px solid rgba(255,255,255,0.64)",
                    boxShadow: active
                      ? "0 8px 32px rgba(217,119,6,0.12), inset 0 1px 0 rgba(255,249,230,0.9)"
                      : "0 4px 18px rgba(0,0,0,0.05), inset 0 1px 0 rgba(255,255,255,0.9)",
                    cursor: "pointer",
                    transition: "all 0.24s ease",
                    display: "flex", flexDirection: "column", gap: "12px",
                    textAlign: "center", alignItems: "center",
                  }}
                >
                  <div style={{
                    width: "52px", height: "52px", borderRadius: "15px",
                    background: active
                      ? "linear-gradient(135deg, #f59e0b, #d97706)"
                      : "rgba(255,255,255,0.72)",
                    border: active ? "none" : "1px solid rgba(245,158,11,0.15)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "24px",
                    boxShadow: active ? "0 6px 18px rgba(217,119,6,0.32)" : "0 2px 8px rgba(0,0,0,0.06)",
                  }}>
                    {cat.emoji}
                  </div>
                  <p style={{ margin: 0, fontSize: "13.5px", fontWeight: "800", color: active ? "#92400e" : "#1c1917" }}>{cat.name}</p>
                  <p style={{ margin: 0, fontSize: "11px", color: active ? "#b45309" : "#a8a29e", fontWeight: "500" }}>{cat.count}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── PRODUCTS ── */}
      <section id="collection" style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div style={{ marginBottom: "32px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <p style={{ margin: "0 0 8px 0", fontSize: "12.5px", fontWeight: "700", color: "#d97706", letterSpacing: "0.06em", textTransform: "uppercase" }}>▪ كولكشن مختار</p>
              <h2 style={{ margin: 0, fontSize: "clamp(26px, 3vw, 38px)", fontWeight: "900", color: "#1c1917", letterSpacing: "-0.025em" }}>القطع الأكثر طلباً</h2>
            </div>
            <div style={{ display: "flex", gap: "8px" }}>
              {["الكل", "صالة", "نوم", "طعام"].map((f, i) => (
                <button
                  key={i}
                  style={{
                    padding: "7px 16px", borderRadius: "10px",
                    background: i === 0 ? "linear-gradient(135deg, rgba(245,158,11,0.15), rgba(217,119,6,0.09))" : "rgba(255,255,255,0.44)",
                    backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
                    border: i === 0 ? "1px solid rgba(245,158,11,0.32)" : "1px solid rgba(255,255,255,0.64)",
                    color: i === 0 ? "#92400e" : "#78716c",
                    fontSize: "12.5px", fontWeight: "600", cursor: "pointer", fontFamily: "'Cairo', sans-serif",
                  }}
                >{f}</button>
              ))}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px" }}>
            {PRODUCTS.map((product, i) => (
              <div
                key={i}
                className="glass-card"
                style={{ borderRadius: "28px", overflow: "hidden" }}
              >
                {/* Illustration area */}
                <div style={{
                  height: "196px",
                  background: `linear-gradient(${130 + i * 22}deg, rgba(245,158,11,0.065) 0%, rgba(255,255,255,0.38) 55%, rgba(217,119,6,0.045) 100%)`,
                  borderBottom: "1px solid rgba(255,255,255,0.62)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  position: "relative", overflow: "hidden",
                }}>
                  {/* Subtle top shine */}
                  <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: "1px", background: "linear-gradient(90deg, transparent, rgba(245,158,11,0.28), transparent)" }} />

                  {product.tag && (
                    <div style={{
                      position: "absolute", top: "12px", right: "12px",
                      padding: "4px 12px", borderRadius: "100px",
                      background: product.tag === "جديد"
                        ? "rgba(245,158,11,0.14)"
                        : product.tag === "مميز"
                        ? "rgba(217,119,6,0.14)"
                        : "rgba(180,83,9,0.12)",
                      border: `1px solid ${product.tag === "جديد" ? "rgba(245,158,11,0.38)" : product.tag === "مميز" ? "rgba(217,119,6,0.38)" : "rgba(180,83,9,0.28)"}`,
                      fontSize: "11px", fontWeight: "700", color: "#92400e",
                    }}>
                      {product.tag}
                    </div>
                  )}

                  <FurnitureSilhouette type={product.type} />
                </div>

                {/* Info */}
                <div style={{ padding: "18px 20px 20px" }}>
                  <p style={{ margin: "0 0 3px 0", fontSize: "11px", color: "#a8a29e", fontWeight: "500" }}>{product.material}</p>
                  <p style={{ margin: "0 0 14px 0", fontSize: "16.5px", fontWeight: "800", color: "#1c1917", letterSpacing: "-0.02em" }}>{product.name}</p>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <span style={{ fontSize: "21px", fontWeight: "900", color: "#d97706", letterSpacing: "-0.02em" }}>{product.price}</span>
                      <span style={{ fontSize: "11px", color: "#a8a29e", marginRight: "5px" }}> دينار</span>
                    </div>
                    <button style={{
                      padding: "8px 18px", borderRadius: "11px",
                      background: "linear-gradient(135deg, rgba(245,158,11,0.14), rgba(217,119,6,0.09))",
                      border: "1px solid rgba(245,158,11,0.32)",
                      color: "#92400e", fontSize: "12.5px", fontWeight: "700",
                      cursor: "pointer", fontFamily: "'Cairo', sans-serif",
                    }}>اطلب ←</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BRAND PROMISE ── */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div
            className="glass"
            style={{
              borderRadius: "40px", padding: "64px 72px",
              display: "grid", gridTemplateColumns: "1fr 1fr", gap: "64px",
              alignItems: "center", overflow: "hidden", position: "relative",
            }}
          >
            {/* Glow spot */}
            <div style={{
              position: "absolute", top: "-80px", left: "38%",
              width: "360px", height: "360px", borderRadius: "50%",
              background: "radial-gradient(circle, rgba(245,158,11,0.09) 0%, transparent 70%)",
              pointerEvents: "none",
            }} />

            {/* Text side */}
            <div style={{ position: "relative" }}>
              <p style={{ margin: "0 0 10px 0", fontSize: "12.5px", fontWeight: "700", color: "#d97706", letterSpacing: "0.06em" }}>▪ وعدنا لك</p>
              <h2 style={{
                margin: "0 0 20px 0",
                fontSize: "clamp(26px, 3vw, 40px)", fontWeight: "900",
                color: "#1c1917", lineHeight: "1.12", letterSpacing: "-0.025em",
              }}>
                جودة لا تُساوَم
                <br />
                <span style={{ color: "#d97706" }}>عليها، وخدمة تستحقها</span>
              </h2>
              <p style={{ margin: "0 0 32px 0", fontSize: "14.5px", lineHeight: "1.85", color: "#78716c", fontWeight: "400" }}>
                كل قطعة أثاث تخرج من ورشنا تمر بمراحل صارمة من مراقبة الجودة. نستخدم أجود أنواع الخشب المستورد ونضمن لك منتجاً يدوم لأجيال.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                {[
                  "ضمان ٥ سنوات على جميع المنتجات",
                  "توصيل وتركيب مجاني داخل بغداد",
                  "خامات مستوردة ومعتمدة دولياً",
                  "خدمة عملاء متاحة ٢٤ / ٧",
                ].map((item, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                    <span style={{
                      width: "22px", height: "22px", borderRadius: "7px",
                      background: "linear-gradient(135deg, rgba(245,158,11,0.18), rgba(217,119,6,0.12))",
                      border: "1px solid rgba(245,158,11,0.28)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "11px", color: "#d97706", fontWeight: "800", flexShrink: 0,
                    }}>✦</span>
                    <span style={{ fontSize: "14px", color: "#44403c", fontWeight: "500" }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Cards side */}
            <div style={{ display: "flex", flexDirection: "column", gap: "14px", position: "relative" }}>
              {PROMISES.map((item, i) => (
                <div
                  key={i}
                  className="glass-strong"
                  style={{
                    padding: "20px 22px", borderRadius: "20px",
                    display: "flex", alignItems: "center", gap: "16px",
                  }}
                >
                  <div style={{
                    width: "50px", height: "50px", borderRadius: "14px", flexShrink: 0,
                    background: "linear-gradient(145deg, rgba(245,158,11,0.15), rgba(217,119,6,0.08))",
                    border: "1px solid rgba(245,158,11,0.24)",
                    display: "flex", alignItems: "center", justifyContent: "center", fontSize: "22px",
                    boxShadow: "inset 0 1px 0 rgba(255,249,230,0.8)",
                  }}>
                    {item.icon}
                  </div>
                  <div>
                    <p style={{ margin: 0, fontSize: "15px", fontWeight: "800", color: "#1c1917", letterSpacing: "-0.01em" }}>{item.title}</p>
                    <p style={{ margin: 0, fontSize: "13px", color: "#78716c", fontWeight: "400" }}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div style={{ marginBottom: "32px", textAlign: "center" }}>
            <p style={{ margin: "0 0 8px 0", fontSize: "12.5px", fontWeight: "700", color: "#d97706", letterSpacing: "0.06em" }}>▪ ماذا يقول عملاؤنا</p>
            <h2 style={{ margin: 0, fontSize: "clamp(26px, 3vw, 38px)", fontWeight: "900", color: "#1c1917", letterSpacing: "-0.025em" }}>آراء حقيقية من عملاء حقيقيين</h2>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "18px" }}>
            {[
              { name: "أحمد الكاظمي", city: "بغداد — الكرادة", text: "طقم الصالة الذي اشتريته من رشاد هوم تجاوز توقعاتي بكثير. الجودة استثنائية والتوصيل كان في الموعد تماماً.", stars: 5 },
              { name: "سارة الموسوي", city: "بغداد — المنصور", text: "غرفة النوم التي صمموها لنا بالمقاسات الخاصة كانت رائعة. فريق محترف وخدمة ما بعد البيع ممتازة جداً.", stars: 5 },
              { name: "محمد العبيدي", city: "بصرة", text: "أفضل أثاث جربته في العراق. الخامات أصلية وكما وصفوها بالضبط. سأتعامل معهم مجدداً بدون تردد.", stars: 5 },
            ].map((t, i) => (
              <div
                key={i}
                className="glass-card"
                style={{ borderRadius: "26px", padding: "28px 26px", display: "flex", flexDirection: "column", gap: "16px" }}
              >
                {/* Stars */}
                <div style={{ display: "flex", gap: "3px" }}>
                  {[0,1,2,3,4].map(s => <span key={s} style={{ color: "#f59e0b", fontSize: "15px" }}>★</span>)}
                </div>
                {/* Text */}
                <p style={{ margin: 0, fontSize: "14px", lineHeight: "1.75", color: "#44403c", fontWeight: "400", fontStyle: "italic" }}>
                  "{t.text}"
                </p>
                {/* Author */}
                <div style={{ display: "flex", alignItems: "center", gap: "12px", marginTop: "auto", paddingTop: "12px", borderTop: "1px solid rgba(245,158,11,0.12)" }}>
                  <div style={{
                    width: "40px", height: "40px", borderRadius: "50%",
                    background: `linear-gradient(${135 + i * 45}deg, rgba(245,158,11,0.25), rgba(217,119,6,0.15))`,
                    border: "2px solid rgba(245,158,11,0.25)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "17px", fontWeight: "900", color: "#d97706",
                  }}>
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p style={{ margin: 0, fontSize: "13.5px", fontWeight: "800", color: "#1c1917" }}>{t.name}</p>
                    <p style={{ margin: 0, fontSize: "11.5px", color: "#a8a29e", fontWeight: "400" }}>{t.city}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 28px 80px" }}>
        <div
          className="glass-amber"
          style={{
            maxWidth: "1180px", margin: "0 auto",
            borderRadius: "40px", padding: "72px 80px",
            textAlign: "center", position: "relative", overflow: "hidden",
          }}
        >
          {/* Center glow */}
          <div style={{
            position: "absolute", top: "50%", left: "50%",
            transform: "translate(-50%, -50%)",
            width: "420px", height: "420px", borderRadius: "50%",
            background: "radial-gradient(circle, rgba(245,158,11,0.13) 0%, transparent 70%)",
            pointerEvents: "none",
          }} />
          {/* Top shine */}
          <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: "1px", background: "linear-gradient(90deg, transparent, rgba(245,158,11,0.35), transparent)" }} />

          <p style={{ margin: "0 0 14px 0", fontSize: "12.5px", fontWeight: "700", color: "#b45309", letterSpacing: "0.06em", position: "relative" }}>▪ رشاد هوم — بغداد، العراق</p>
          <h2 style={{
            margin: "0 0 18px 0", position: "relative",
            fontSize: "clamp(30px, 4vw, 52px)", fontWeight: "900",
            color: "#1c1917", letterSpacing: "-0.03em", lineHeight: "1.1",
          }}>
            بيتك ينتظر<br/>
            <span style={{ color: "#d97706" }}>لمستك الأخيرة</span>
          </h2>
          <p style={{
            margin: "0 auto 44px", fontSize: "15.5px", color: "#78716c",
            lineHeight: "1.75", maxWidth: "460px", position: "relative",
          }}>
            تواصل معنا اليوم واحصل على استشارة تصميم مجانية. نحن نساعدك تختار ما يناسب مساحتك وذوقك وميزانيتك.
          </p>
          <div style={{ display: "flex", gap: "16px", justifyContent: "center", position: "relative", flexWrap: "wrap" }}>
            <button style={{
              padding: "16px 44px", borderRadius: "18px",
              background: "linear-gradient(135deg, #f59e0b, #d97706)",
              border: "none", color: "white", fontSize: "16px", fontWeight: "800",
              cursor: "pointer", fontFamily: "'Cairo', sans-serif",
              boxShadow: "0 10px 36px rgba(217,119,6,0.36), inset 0 1px 0 rgba(255,255,255,0.22)",
            }}>
              📞 تواصل الآن
            </button>
            <button style={{
              padding: "16px 36px", borderRadius: "18px",
              background: "rgba(255,255,255,0.62)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)",
              border: "1px solid rgba(255,255,255,0.78)", color: "#92400e",
              fontSize: "16px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif",
              boxShadow: "0 4px 16px rgba(0,0,0,0.06)",
            }}>
              🏠 زر معرضنا
            </button>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ position: "relative", zIndex: 1, padding: "0 28px 48px" }}>
        <div style={{ maxWidth: "1180px", margin: "0 auto" }}>
          <div
            className="glass"
            style={{
              borderRadius: "32px", padding: "52px 64px",
              display: "grid", gridTemplateColumns: "2.2fr 1fr 1fr 1fr", gap: "48px",
            }}
          >
            {/* Brand */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "18px" }}>
                <div style={{
                  width: "38px", height: "38px", borderRadius: "11px",
                  background: "linear-gradient(135deg, #f59e0b, #d97706)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: "0 4px 14px rgba(217,119,6,0.32)",
                }}>
                  <span style={{ color: "white", fontSize: "17px", fontWeight: "900" }}>ر</span>
                </div>
                <div>
                  <div style={{ fontSize: "17px", fontWeight: "900", color: "#1c1917", letterSpacing: "-0.02em" }}>رشاد هوم</div>
                  <div style={{ fontSize: "10px", color: "#a8a29e", letterSpacing: "0.04em" }}>RASHAD HOME</div>
                </div>
              </div>
              <p style={{ fontSize: "13.5px", color: "#78716c", lineHeight: "1.75", margin: "0 0 22px 0", maxWidth: "230px", fontWeight: "400" }}>
                أثاث فاخر يجمع بين الذوق الراقي والجودة العالية — بحرفية عراقية أصيلة منذ عام ٢٠٠٩.
              </p>
              {/* Social */}
              <div style={{ display: "flex", gap: "10px" }}>
                {["📘", "📸", "💬", "🐦"].map((icon, i) => (
                  <div key={i} style={{
                    width: "34px", height: "34px", borderRadius: "10px",
                    background: "rgba(255,255,255,0.6)", backdropFilter: "blur(12px)",
                    border: "1px solid rgba(245,158,11,0.18)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "15px", cursor: "pointer",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                  }}>{icon}</div>
                ))}
              </div>
            </div>

            {/* Links */}
            {[
              { title: "تصفح", links: ["الرئيسية", "الكولكشن", "الغرف", "العروض الخاصة"] },
              { title: "خدماتنا", links: ["تصميم مخصص", "التوصيل والتركيب", "ضمان المنتجات", "ما بعد البيع"] },
              { title: "تواصل معنا", links: ["بغداد — الكرادة", "بغداد — المنصور", "+964 770 123 4567", "info@rashadhome.iq"] },
            ].map((col, i) => (
              <div key={i}>
                <p style={{ margin: "0 0 18px 0", fontSize: "14px", fontWeight: "800", color: "#1c1917", letterSpacing: "-0.01em" }}>{col.title}</p>
                <div style={{ display: "flex", flexDirection: "column", gap: "11px" }}>
                  {col.links.map((link, j) => (
                    <a key={j} href="#" style={{
                      fontSize: "13px", color: "#78716c", textDecoration: "none",
                      fontWeight: "400", transition: "color 0.15s ease",
                    }}>{link}</a>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Bottom bar */}
          <div style={{
            marginTop: "20px", padding: "16px 32px",
            background: "rgba(255,255,255,0.35)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)",
            border: "1px solid rgba(255,255,255,0.55)", borderRadius: "16px",
            display: "flex", justifyContent: "space-between", alignItems: "center",
            boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
          }}>
            <span style={{ fontSize: "12px", color: "#a8a29e" }}>© ٢٠٢٥ رشاد هوم — جميع الحقوق محفوظة</span>
            <div style={{ display: "flex", gap: "20px" }}>
              {["سياسة الخصوصية", "الشروط والأحكام", "سياسة الإرجاع"].map((l, i) => (
                <a key={i} href="#" style={{ fontSize: "11.5px", color: "#a8a29e", textDecoration: "none" }}>{l}</a>
              ))}
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
